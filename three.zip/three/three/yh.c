//#define _CRT_SECURE_NO_WARNINGS 1
//#include <stdio.h>
//#include <stdlib.h>
//#include <time.h>
//int sun()
//{
//	int x, y, z;
//	x = 1;
//	y = 2;
//	z = x + y;
//	return z;
//}
//int main()
//{
//	int a = 1;
//	int b = 2;
//	/*int c=time(NULL);
//	printf("%d\n", time(NULL));
//	printf("%d\n", rand());*/
//	int d=sun(a, b);
//	printf("%d\n",sun());
//	return 0;
//}