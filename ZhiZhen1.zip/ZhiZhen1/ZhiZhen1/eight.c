#include <stdio.h>
//int main()
//{
//	int a = 3;
//	/*printf("%d\n", *&a);*/
//	char* p = &a;
//	*p = 0;
//	printf("%d\n", p);
//	return 0;
//}
//int main()
//{
//	int a = 0x11223344;
//	int* pa = &a;
//	char* pc = &a;
//	printf("%p\n", pa);
//	printf("%p\n", pa+1);	
//	printf("%p\n", pc);
//	printf("%p\n", pc+1);
//	return 0;
//}

//int main()
//{
//	int arr[10] = { 0 };
//	//int arr1[][3] = { 0 };
//	/*int a = 1;
//	&a;
//	printf("%p\n", &a);
//	printf("%p\n", &a + 1);*/
//	int* p = arr;//����������Ԫ�ص�ַ
//	int i = 0;
//	for (i = 0; i < 10; i++)
//	{
//		*(p + i) = 1;
//		printf("%d ", arr[i]);
//	}
//	
//
//	return 0;
//
//}
int main()
{
	/*int a;
	int* p;
	printf("%p\n", p);*/

	int arr[10] = { 0 };
	int* p = &arr;
	printf("%p\n", &arr);
	printf("%p\n", p+9);
	printf("%p\n", p+10);
	return 0;
}
