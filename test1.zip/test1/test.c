#define _CRT_SECURE_NO_WARNINGS 1��
#include <stdio.h>
#include <string.h>
//#define MAX(X,Y) ((X)*(Y))
//#define MAX(X,Y) (X>Y?X:Y)
// 
	
//struct book
//{
//	char name[1];
//	short d;
//	short g;
//	int price;
//	double a;
//};
//struct person
//{
//	char name[20];
//	int age;
//	char male[3];
//};
int main()
{

//	struct person a = { "��һ",88,"��" };
//	printf("%s\n", a.name);
//	printf("%d\n", a.age);
//	printf("%s\n", a.male);
	/*int a = 5, b = 6, c = 7, d = 8, m = 2, n = 2;
	(m = a < b) || (n = c > d);
	printf("%d\t%d", m, n);
	int max = (a > b ? a : b);
	printf("%d\n", max);*/
	/*printf("%d\n",sizeof(struct book));*/
	/*int arr[5] = { 1,2,3 };
	printf("%d\n", arr[1]);
	printf("%d\n", strlen(arr));*/
	/*struct book b1 = {65,5};
	printf("%s\n", b1.name);
	printf("%d\n", b1.price);
	strcpy(b1.name, "1,2,3");
	printf("%s\n", b1.name);*/
	//int a = 10;
	//int b = 50;
	///*MAX(a,b);*/
	//printf("%d\n", MA
	//X(a,b));
	/*char a = 'n';
	printf("%c\n", a);*/

	/*int a = 10;
	int* p = &a;
	printf("%d\n",*p);
	printf("%p\n", &a);
	printf("%p\n", p);

	printf("%d\n", sizeof(p));*/
	return 0;
}
//int MAX(int x, int y)
//{
//	/*int z = x + y;*/
//	
//	int z = (x > y ? x : y);
//	return z;
//}
//int ss()
//{
//	static int a = 1;
//	a++;
//	return a;
//
//}
//int main()
//{
////
////	int i = 1;
////	while (i < 5)
////	{
////		int b=ss();
////		printf("a=%d\n", b);
////		i++;
////	}
//
//
//extern int g_val;
//printf("%d\n", g_val);
//
//	return 0;
//}
	/*int a = 1;
	int b = ~a;
	printf("%d", b);*/

	//int a = 10;
	///*int b = a++;*/
	//int b = ++a;
	//printf("a=%d b=%d\n", a, b);

	/*int a = (int)3.14;*/
	
	//int a = 3;
	//int b = 0;
	///*int c = a && b;*/
	//int c = a || b;
	//printf("%d", c);

	//int a = 10;
	//int b = 20;
	//int max = 0;
	//max = (a > b ? a: b);
	/*printf("%d", max);*/

	/*int a = -5;
	int b = ~a;
	printf("%d\n", b);*/

	/*int a = 1;
	int b = 0;
	int c = 0;
	if (a - b &&  a+b)
	{
		printf("%d\n",a);
	}
	printf("%d",b);*/

	/*char a = 'a';
	char b = 'e';
	printf("%d\n", a - b);*/
	//int a = -1;
	//printf("%d", a);

	/*char a = 48;
	char b = 10;
	printf("%c\n", a-b);
	printf("%c\n", a);*/

	/////*unsigned int a = -1;
	////printf("%d", a);*/

