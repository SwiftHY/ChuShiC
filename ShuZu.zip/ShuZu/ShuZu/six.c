#include <stdio.h>
//int main() 
//{
//	//char arr[4] = "abc";
//	//printf("%s\n", arr);
//	/*int arr[][3] = {1,2,3,4,5};
//	int arr2[] = { 1,2,3,4 };
//	char arr1[3] = {3};
//	char arr3[][2] = { 1,2,3,4 };*/
//	//int arr4[][3] = { {1,2,3} };
// 
// 
//}
//int erfen(int arr[],int k,int sz)
//{
//	int left = 0;
//	int right = sz - 1;
//	while (left < right)
//	{
//		int mid = (left + right) / 2;
//		if (arr[mid] < k)
//		{
//			left = mid + 1;
//		}
//		else if (arr[mid] > k)
//		{
//			right = mid - 1;
//		}
//		else
//		{
//			return arr[mid];
//		}
//	}
//	return -1;
//}
//
//
//
//int main()
//{
//	int arr[] = { 1,2,3,4,5,6,7 };
//	int k = 4;
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	int ret = erfen(arr,k,sz);
//	if (ret == -1)
//	{
//		printf("û�ҵ�\n");
//	}
//	else
//	{
//		printf("�ҵ���\n");
//	}
//}
// 
//ð������
//void bubble_sort(int arr[],int sz)
//{
//	int i = 0;
//	for (i = 0; i < sz - 1; i++)
//	{
//		int flag = 1;
//		int j = 0;
//		for (j = 0; j < sz - 1 - i; j++)
//		{
//			if (arr[j] > arr[j + 1])
//			{
//				int temp = 0;
//				temp = arr[j];
//				arr[j] = arr[j + 1];
//				arr[j + 1] = temp;
//				flag = 0;
//			}
//		}
//		if (flag == 1)
//		{
//			break;
//		}
//	}
//}
//
//int main()
//{
//	int arr[] = {1,3,2,4,5,6,7,8,9};
//	//��arr���������ų�����
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	bubble_sort(arr, sz);//ð�����򷽷�  //arr�����飬���Ƕ�����arr���д��Σ�ʵ���ϴ��ݹ�ȥ��������arr��Ԫ�صĵ�ַ
//	int i = 0;
//	for (i = 0; i < sz; i++)
//	{
//		printf("%d ",arr[i]);
//	}
//	return 0;
//}

//��������ʲô
//int main()
//{
//	int arr[10] = { 1,10,3,4,5 };
//	printf("%p\n", arr);
//	printf("%p\n", &arr[0]);
//	printf("%d\n", *arr);
//	printf("%p\n", arr + 1);
//	printf("%d\n", *(arr + 1));
//	char arr1[] = "a,b,c,d,e";
//	int ret = strlen(arr1);
//	printf("%d\n", ret);
//	printf("%p\n", &arr);
//}
//int main()
//{
//	int n = 10;
//	int *p = &n;
//	printf("%d\n", *&n);
//	printf("%d\n",*p);
	/*int arr[] = { 1,2,3,4 };
	printf("%d\n", *arr);
	int *p = arr;
//	printf("%d\n", *p)*/;
//}