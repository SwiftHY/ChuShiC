void ADD(int* p)
{
	(*p)++;
}