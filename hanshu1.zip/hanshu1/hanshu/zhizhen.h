#pragma once
void ADD(int* p);
//void ADD(int* p)
//{
//	(*p)++;
//}
