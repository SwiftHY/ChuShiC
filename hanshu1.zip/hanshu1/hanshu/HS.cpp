#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <math.h>
//void Swap(int x,int y)
//{
//	int  temp = 0;
//	temp = x;
//	x = y;
//	y = temp;
//}
//int main() 
//{
//	int a = 10;
//	int b = 20;
//	Swap(a, b);
//	printf("%d %d\n", a, b);
//	return 0;
//}

//void Swap2(int* pa,int * pb)
//{
//	int tmp = 0;
//	tmp = *pa;
//	*pa = *pb;
//	*pb = tmp;
//}
//int main()
//{
//	int a = 10;
//	int b = 20;
//	//int* pa = &a;		//paָ�����
//	//int* pb = &b;	//�����ò���
//	Swap2(&a,&b);
//	printf("%d %d\n", a,b);
//}
//void sushu(int x)
//{
//	int i;
//	for (i = 2;i < x;i++)
//	{
//		if (x % i == 0)
//		{
//			printf("su");
//		}
//		else
//		{
//			printf("sud");
//		}
//	}
//
//}

//����������1��������������0
//int is_prime(int n)
//{
//	int i;
//	for (i = 2; i <= sqrt(n); i++)
//	{
//		if (n % i == 0)
//		{
//			return 0;
//		}
//	}
//	return 1;
//}
//int main()
//{
//	int a = 0;
//	printf("����������\n");
//	scanf("%d", &a);
//	if (is_prime(a)== 1)
//	{
//		printf("%d\n", a);
//	}
//	return 0;
//}
//int is_leap_year(int y)
//{
//	if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))
//	{
//		return 1;
//	}
//	else
//	{
//		return 0;
//	}
//}
//
//int main()
//{
//	int year = 0;
//	for (year = 1000; year <= 2000; year++)
//	{
//		//�ж�year�Ƿ�Ϊ����
//		if (is_leap_year(year) == 1)
//		{
//			printf("%d ", year);
//		}
//	}
//	return 0;
//}



//дһ��������ʵ��һ����������������Ķ��ֲ��ҷ�
//int binart_search(int arr[], int k, int sz)
//{
//	int left = 0;
//	int right = sz - 1;
//	while (left <= right)
//	{
//		int mid = (left + right) / 2;
//			if (arr[mid]< k)
//			{
//				left = mid + 1;
//			}
//			else if(arr[mid] > k)
//			{
//				right = mid - 1;
//			}
//			else
//			{
//				return mid;
//			}
//	}
//	return -1;
//}
//int main()
//{
//	int arr[] = { 1,2,3,4,5,6,7,8,9,10 };
//	int k = 7;
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	int ret = binart_search(arr, k,sz);
//	if (ret == -1)
//	{
//		printf("û�ҵ�\n");
//	}
//	else
//	{
//		printf("%d\n", ret);
//	}
//	return 0;
//}



//���ֲ��ҷ�
//int erfen(int arr[], int k, int sz)
//{
//	int left = 0;
//	int right = sz - 1;
//	while (left <= right)
//	{
//		int mid = (right + left) / 2;
//		if (arr[mid] < k)
//		{
//			left = mid + 1;
//		}
//		else if (arr[mid]>k)
//		{
//			right = mid - 1;
//		}
//		else
//		{
//			return mid;
//		}
//	}
//	return -1;
//}
//int main()
//{
//	int arr[] = { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,25,66,71,75,79,85,94,102,455,666,777 };
//	int k = 0;
//	scanf("%d", &k);
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	int ret = erfen(arr, k, sz);
//	if (ret == -1)
//	{
//		printf("û�ҵ�");
//	}
//	else
//	{
//		printf("%d\n", ret);
//	}
//	return 0;
//}

//void ADD(int* p)
//{
//	(*p)++;
//}
#include "zhizhen.h"

int main()
{
	int num = 0;
	ADD(&num);
	printf("%d\n", num);
	ADD(&num);
	printf("%d\n", num); 
	ADD(&num);
	printf("%d\n", num);
	ADD(&num);
	printf("%d\n", num);
	return 0;
}


//��ʽ����
//int main()
//{
//	printf("%d",printf("%d", printf("%d", printf("%d", 43))));
//	int c = printf("%d",44);
//	printf("%d\n",c);
//	return 0;
//}