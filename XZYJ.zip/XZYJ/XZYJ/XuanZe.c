#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

int main()
{
	/*int age = 10;*/
	/*if (age < 18)
		printf("δ����\n");
	else
		printf("����\n");*/

	//if (age < 18)
	//{
	//	printf("δ����\n");
	//	printf("dad\n");
	//}
	//else if(age >= 18 && age <= 28)
	//	printf("����\n");
	//else if(age >= 28 && age <= 50)
	//	printf("׳��\n");
	//else if(age >= 50 && age <= 90)
	//	printf("׳��\n");
	//else
	//	printf("�ϲ���");

	//if (age < 18)
	//	printf("δ����\n");

	/*int a = 0;
	int b = 2;
	if (a == 0)
		if (b == 2)
			printf("hehe\n");
		else
			printf("haha\n");
	else
		printf("dada");*/

	/*int a;
	int b;
	scanf("%d", &a);
	b = a % 2;
	if (b)
		printf("����");
	else
		printf("ż��");*/

	//int a=1;
	//for (; a >= 1 && a <= 100; a++)
	//{
	//	if (a % 2)
	//		printf("%d\n",a);
	//}

	//int day;
	//scanf("%d",&day);
	///*printf("����%d\n", day)*/;

	//switch (day / 2)
	//{
	//case 1:printf("����һ\n"); break;
	//case 2:printf("���ڶ�\n");
	//}
	//printf("dad");

	//int n = 1;
	//int m = 2;
	//switch (n)
	//{
	//case 1:m++;
	//case 2:n++;
	//	case 3:switch (n)
	//	{
	//	case 1:n++;
	//	case 2:m++; n++; break;
	//	}
	//	case 4: {m++; }
	//		break;
	//	default:
	//		break;
	//}
	//printf("%d %d\n", m, n);


	/*while (1)
	{
		printf("����");
	}*/

	/*int i = 1;;
	while (i <= 10)
	{
		if (i == 5)
		{
			continue;
		}
		printf("%d\n", i);
		i++;
	}*/
	//for (int i = 1; i <= 10; i++)
	//{
	//	printf("%d\n", i);
	//}

	/*int a;
	a=getchar();
	printf("a=%c\n", a);
	getchar();
	char b;
	scanf("%c",&b);
	printf("b=%c\n", b);*/

	/*int ch;
	while ((ch = getchar()) != EOF)
	{
		putchar(ch);
		printf("%c", ch);

	}*/
	/*int a;*/
	/*scanf("%c", &a);*/
	//a = getchar();
	/*putchar(a);*/

	/*int ch = 0;
	while ((ch = getchar()) != EOF)
	{
		if (ch < '0' || ch>'9')
		{
			continue;
		}
		putchar(ch);
	}*/
int i;
	for (i = 1; i <= 10; i++)
	{
		if (i == 5)
		{
			continue;
		}
		printf("%d", i);
	}
	printf("%d\n", i);
	return 0;
}