#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
//int main()
//{
//	int a = 5;
//	int b = 2;
//	double  c  = a / b;
//	printf("%lf\n", c);
//	return 0;
//}
//int main()
//{
//	//int a = 16;
//	//int c = -1;
//	////���Ʋ�����
//	////�ƶ����Ƕ�����λ
//	////000000000000000000000000000000000000000010000
//	//int b = a >> 1;
//	//printf("%d\n", b);
//	//int d = c >> 1;
//	//printf("%d\n", d);
//	int a = -1;
//	int b = a << 1;
//	printf("%d\n", b);
//	return 0;
//}
//int main()
//{
//	//& --��2����ޱ��
//	int a = 3;
//	int b = 5;
//	int c = a & b;
//	int d = a | b;
//	int e = a ^ b;
//	printf("%d\n", c);
//	printf("%d\n", d);
//	printf("%d\n", e);
//	return 0;
//}


//int main()
//{
//	int a = 3;
//	int b = 5;
//
//
//	//�Ӽ���
//	/*printf("before a =%d b =%d\n", a, b);
//	a = a + b;
//	b = a - b;
//	a = a - b;
//	printf("result a =%d b =%d\n", a, b);*/
//
//	//���ķ���
//	a = a ^ b;
//	b = a ^ b;
//	a = a ^ b;
//
//
//	return 0;
//}

//int main()
//{
//	int num = 0;
//	int count = 0;
//	scanf("%d", &num);
//	//ͳ��num�Ĳ������м���1
//	/*while (num)
//	{
//		if (num % 2 == 1)
//		{
//			count++;
//		
//		}
//		num = num / 2;
//	}*/
//
//	int i = 0;
//	for (i = 0; i < 32; i++)
//	{
//		if (1 == ((num >> i) & 1))
//		{
//			count++;
//		}
//	}
//	printf("%d\n", count);
//	return 0;
//}

//int main()
//{
//	int a = 10;
//	if (a)
//	{
//		printf("%d\n", !a);
//	}
//	int b = 0;
//	if (!b)
//	{
//		printf("hehe");
//	}
//	return 0;
//}

//int main()
//{
//	int a = 10;
//	int* p = &a;
//	int arr[10] = { 0 };
//	printf("%d\n", *p);
//	printf("%d\n", sizeof(int));
//	printf("%d\n", sizeof(a));
//	printf("%d\n", sizeof(int *));
//	printf("%d\n", sizeof(p));
//	printf("%d\n", sizeof(arr));
//	printf("%d\n", sizeof(int [10]));
//	printf("%d\n", sizeof(int[5]));
//	printf("%d\n", sizeof(2));
//	return 0;
//}


struct man
{
	char name[20];
	int age;
	char faberatecolor[20];
	int height;
	int weight;
	int dad;
};
int main()
{
	struct man p1 = { "����",21,"��ɫ",171,120 };
	printf("%s\n", p1.name);
	printf("%d\n", p1.age);
	printf("%s\n", p1.faberatecolor);
	printf("%d\n", p1.height);
	printf("%d\n", p1.weight);
	printf("%d\n", sizeof(struct man));
	printf("%d\n", sizeof(p1));

	return 0;
}